<template>
  <div class="table-wrap">
    <!-- header -->
    <div class="table-top">
      <div>
        <div class="table-title">{{ title }}</div>
        <div class="table-sub">{{ tasks.length }} tasks</div>
      </div>

      <div class="table-top-actions">
        <select
          class="page-size"
          :value="pageSize"
          @change="$emit('update:pageSize', Number($event.target.value))"
        >
          <option :value="5">5</option>
          <option :value="8">8</option>
          <option :value="10">10</option>
          <option :value="20">20</option>
        </select>
      </div>
    </div>

    <!-- table -->
    <div class="table-scroll">
      <table class="task-table">
        <thead>
          <tr>
            <th style="width:40px;">
              <input type="checkbox" />
            </th>
            <th style="width:60px;">NO</th>
            <th style="width:220px;">Task Name</th>
            <th>Description</th>
            <th style="width:140px;">Date</th>
            <th style="width:140px;">Category</th>
            <th style="width:120px;">Priority</th>
            <th style="width:140px;">Status</th>
            <th style="width:70px; text-align:center;">Action</th>
          </tr>
        </thead>

<tr v-for="(t, index) in paginated" :key="t.id">
  <td style="width:40px;">
    <input type="checkbox" />
  </td>

  <td class="no" style="width:60px;">
    {{ (currentPage - 1) * pageSize + index + 1 }}
  </td>

  <td class="task-name" style="width:220px;" @click="$emit('view', t)">
    <div class="name">{{ t.title || "No title" }}</div>
  </td>

  <td class="desc" @click="$emit('view', t)">
    {{ (t.content || t.notes || "No description").trim() }}
  </td>

  <td class="date" style="width:140px;">{{ t.date || "—" }}</td>

  <td style="width:140px;">
    <span class="tag category">{{ showCategory(t.category) }}</span>
  </td>

  <td style="width:120px;">
    <span class="tag" :class="priorityClass(showPriority(t.priority))">
      {{ showPriority(t.priority) }}
    </span>
  </td>

  <td style="width:140px;">
    <span class="tag status" :class="{ done: !!t.isCompleted }">
      {{ t.isCompleted ? "Done" : "Pending" }}
    </span>
  </td>

  <td class="action" style="width:70px; text-align:center;">
    <button class="dots" @click.stop="toggleMenu(t.id)">⋯</button>
  </td>
</tr>


      </table>
    </div>

    <!-- footer -->
    <div class="table-foot">
      <div class="page-info">
        Page <b>{{ currentPage }}</b> / <b>{{ totalPages }}</b>
      </div>

      <div class="pager">
        <button class="pager-btn" :disabled="currentPage === 1" @click="currentPage--">
          Prev
        </button>
        <button class="pager-btn" :disabled="currentPage === totalPages" @click="currentPage++">
          Next
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref, watch } from "vue";

const props = defineProps({
  title: { type: String, default: "All Tasks" },
  tasks: { type: Array, default: () => [] },
  pageSize: { type: Number, default: 8 },
});

defineEmits(["update:pageSize", "view", "edit", "delete"]);

const currentPage = ref(1);
const openMenuId = ref(null);

watch(
  () => props.pageSize,
  () => (currentPage.value = 1)
);

watch(
  () => props.tasks,
  () => (currentPage.value = 1)
);

const totalPages = computed(() =>
  Math.max(1, Math.ceil(props.tasks.length / props.pageSize))
);

const paginated = computed(() => {
  const start = (currentPage.value - 1) * props.pageSize;
  return props.tasks.slice(start, start + props.pageSize);
});

const toggleMenu = (id) => {
  openMenuId.value = openMenuId.value === id ? null : id;
};

// UI mapping
const showPriority = (val) => {
  const v = String(val || "").toUpperCase();
  if (v === "HIGH" || val === "ខ្ពស់") return "High";
  if (v === "MEDIUM" || val === "មធ្យម") return "Medium";
  if (v === "LOW" || val === "ទាប") return "Low";
  return "Medium";
};

const showCategory = (val) => {
  const v = String(val || "").toUpperCase();
  if (v === "PERSONAL" || val === "ផ្ទាល់ខ្លួន") return "Personal";
  if (v === "WORK" || val === "ការងារ") return "Work";
  if (v === "SCHOOL" || v === "STUDY" || val === "សិក្សា") return "Study";
  return "General";
};

const priorityClass = (p) => {
  if (p === "High") return "high";
  if (p === "Medium") return "medium";
  return "low";
};
</script>

<style scoped>

/* 🔥 FORCE REAL TABLE MODE (fix vertical issue) */
.task-table,
.task-table thead,
.task-table tbody,
.task-table tr,
.task-table th,
.task-table td {
  display: table-cell !important;
}

.task-table tr {
  display: table-row !important;
}

.task-table thead {
  display: table-header-group !important;
}

.task-table tbody {
  display: table-row-group !important;
}

.task-table {
  display: table !important;
  width: 100%;
  table-layout: fixed;
}

.table-wrap {
  background: rgba(255, 255, 255, 0.92);
  border: 1px solid rgba(226, 232, 240, 0.9);
  border-radius: 22px;
  overflow: hidden;
  box-shadow: 0 18px 40px -30px rgba(15, 23, 42, 0.25);
}

.table-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 14px 16px;
  background: linear-gradient(
    135deg,
    rgba(13, 148, 136, 0.12),
    rgba(6, 182, 212, 0.08)
  );
  border-bottom: 1px solid rgba(226, 232, 240, 0.9);
}

.table-title {
  font-weight: 900;
  color: #0f172a;
  font-size: 14px;
}
.table-sub {
  font-weight: 800;
  color: #64748b;
  font-size: 12px;
}

.page-size {
  padding: 8px 10px;
  border-radius: 14px;
  border: 1px solid #e2e8f0;
  background: #fff;
  font-weight: 900;
}

.table-scroll {
  overflow: auto;
}

.task-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  min-width: 980px;
  table-layout: fixed; /* 🔥 IMPORTANT */
}

.task-table thead th {
  position: sticky;
  top: 0;
  background: #fff;
  z-index: 2;
  font-size: 12px;
  font-weight: 900;
  color: #334155;
  padding: 12px 14px;
  border-bottom: 1px solid #e2e8f0;
  text-align: left;
}

.task-table tbody td {
  padding: 12px 14px;
  border-bottom: 1px solid #f1f5f9;
  font-weight: 800;
  color: #0f172a;
  font-size: 13px;
  vertical-align: middle;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.row:hover {
  background: rgba(13, 148, 136, 0.06);
}

.no {
  color: #64748b;
  font-weight: 900;
}

.task-name .name {
  font-weight: 900;
}

.desc {
  color: #64748b;
}

.tag {
  font-weight: 900;
  font-size: 11px;
  padding: 6px 10px;
  border-radius: 999px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border: 1px solid #e2e8f0;
}

.tag.category {
  background: rgba(13, 148, 136, 0.08);
  border-color: rgba(13, 148, 136, 0.2);
  color: #0d9488;
}

.tag.high {
  background: #fee2e2;
  color: #dc2626;
  border-color: rgba(220, 38, 38, 0.25);
}
.tag.medium {
  background: #fef3c7;
  color: #d97706;
  border-color: rgba(217, 119, 6, 0.25);
}
.tag.low {
  background: #dcfce7;
  color: #16a34a;
  border-color: rgba(22, 163, 74, 0.25);
}

.tag.status {
  background: #fff;
  color: #ef4444;
}
.tag.status.done {
  background: #f0fdfa;
  color: #0d9488;
  border-color: rgba(13, 148, 136, 0.25);
}

.action {
  position: relative;
  text-align: right;
}

.dots {
  width: 38px;
  height: 38px;
  border-radius: 14px;
  border: 1px solid #e2e8f0;
  background: #fff;
  font-weight: 900;
  cursor: pointer;
}

.menu {
  position: absolute;
  right: 10px;
  top: 46px;
  width: 160px;
  background: #fff;
  border: 1px solid rgba(226, 232, 240, 0.9);
  border-radius: 16px;
  box-shadow: 0 20px 40px -26px rgba(15, 23, 42, 0.35);
  overflow: hidden;
  z-index: 20;
}

.menu button {
  width: 100%;
  padding: 10px 12px;
  border: none;
  background: transparent;
  text-align: left;
  font-weight: 900;
  cursor: pointer;
}

.menu button:hover {
  background: rgba(13, 148, 136, 0.06);
}

.menu button.danger {
  color: #ef4444;
}

.table-foot {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: #fff;
  border-top: 1px solid rgba(226, 232, 240, 0.9);
}

.page-info {
  font-weight: 900;
  color: #64748b;
}

.pager {
  display: flex;
  gap: 10px;
}

.pager-btn {
  padding: 10px 14px;
  border-radius: 14px;
  border: 1px solid #e2e8f0;
  background: #fff;
  font-weight: 900;
  cursor: pointer;
}
.pager-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
