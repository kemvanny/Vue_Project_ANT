<template>
  <TaskLedger initialStatus="all" />
</template>

<script setup>
import TaskLedger from '../../components/userdashboard/TaskLedger.vue';
</script>